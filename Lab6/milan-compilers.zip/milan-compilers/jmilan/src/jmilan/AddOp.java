package jmilan;

public enum AddOp {
    ADD, // "+"
    SUB  // "-"
}
