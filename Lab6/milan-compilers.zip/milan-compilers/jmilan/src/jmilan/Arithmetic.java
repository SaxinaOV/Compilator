package jmilan;

public enum Arithmetic {
    PLUS,
    MINUS,
    MULTIPLY,
    DIVIDE
}
