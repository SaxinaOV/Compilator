package jmilan;

public enum Cmp {
    EQ, // =
    NE, // !=
    LT, // <
    LE, // <=
    GT, // >
    GE  // >=
}
