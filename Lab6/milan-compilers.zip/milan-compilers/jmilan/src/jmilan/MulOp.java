package jmilan;

public enum MulOp {
    MUL, // "*"
    DIV  // "/"
}
